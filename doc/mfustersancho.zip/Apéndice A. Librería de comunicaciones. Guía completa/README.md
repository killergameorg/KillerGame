## Librería de comunicaciones: Guía completa

### Aspectos generales

#### Comprendiendo los fundamentos de la red

La librería de comunicaciones que se presenta a continuación ofrece a las máquinas la capacidad de establecer conexiones punto a punto (P2P) utilizando el protocolo TCP/IP en una red local. En adelante, nos referiremos a cada máquina conectada a la red P2P como "peer". Cada peer cuenta con una lista de direcciones IP de otros peers en la red, así como un servidor al cual otros peers pueden conectarse.

### Estableciendo conexiones P2P

El objetivo principal de esta librería es permitir la comunicación eficiente y segura entre peers en una red local. Para lograrlo, cada peer utiliza el protocolo TCP/IP para establecer conexiones directas con otros peers en la red. Esto significa que cada peer actúa tanto como cliente, al conectarse a otros peers, como servidor, al aceptar conexiones entrantes de otros peers.

### Ventajas de la librería de comunicaciones

La librería de comunicaciones ofrece una serie de ventajas clave que mejoran la experiencia de comunicación entre los peers de la red:

1. **Conexiones P2P eficientes:** Utilizando el protocolo TCP/IP, los peers pueden establecer conexiones directas, lo que permite una comunicación rápida y eficiente entre ellos.

2. **Escalabilidad:** La librería permite gestionar una lista de direcciones IP de otros peers en la red, lo que facilita la expansión de la red y la inclusión de nuevos peers.

3. **Seguridad:** La comunicación se lleva a cabo dentro de una red local, lo que reduce los riesgos de accesos no autorizados y mejora la seguridad de la información transmitida.

4. **Flexibilidad:** Cada peer puede actuar como cliente y servidor, lo que brinda flexibilidad en la configuración y permite una comunicación bidireccional.

### Utilizando la librería de comunicaciones

Para utilizar esta librería de comunicaciones en tu proyecto, sigue los siguientes pasos:

1. **Instalación:** Sitúa los paquetes `communications` y `communications.frames` en la raíz de tu proyecto.

2. **Configuración:** Define la dirección IP del servidor y establece las conexiones con otros peers en la red. Asegúrate de tener una lista actualizada de las direcciones IP de los peers con los que deseas comunicarte. Para ello edita el archivo `connections.properties` según convenga.

3. **Implementación:** Utiliza los métodos proporcionados por la librería para establecer y gestionar las conexiones P2P. Puedes enviar y recibir datos, así como controlar el estado de las conexiones.

4. **Mantenimiento:** Mantén actualizada tu lista de peers y gestiona las conexiones de manera adecuada. Realiza pruebas y soluciona cualquier problema que pueda surgir durante la comunicación.

Con esta librería de comunicaciones podrás establecer conexiones P2P eficientes y seguras en una red local, facilitando la comunicación entre las máquinas y permitiendo un intercambio de información fluido. ¡Aprovecha las ventajas de esta herramienta y mejora la comunicación en tu proyecto!

## Estructurando una red funcional

Para construir una red P2P funcional utilizando esta librería de comunicaciones, es importante establecer una lista inicial de direcciones IP. Esta lista permitirá a cada peer conectarse con otros peers y así formar la estructura básica de la red. En la red P2P, las conexiones se establecen directamente entre los peers.

Es fundamental que cada peer tenga al menos una conexión con otro peer en la red para garantizar la conectividad de la red. Esto significa que cada peer debe tener al menos un camino hacia cualquier otro peer en la red. Esta configuración asegurará que los datos y la información puedan ser transmitidos de manera eficiente y confiable entre los peers.

Al establecer la lista inicial de IPs, es recomendable incluir direcciones de peers que tengan una alta disponibilidad y estabilidad en la red. Esto ayudará a mantener la conectividad y reducirá la posibilidad de interrupciones en la comunicación.

Recuerda que la estructura de la red P2P se basa en la interconexión de peers individuales, lo que permite una distribución efectiva de la carga y la escalabilidad de la red. Cada peer actúa como un nodo en la red, facilitando la comunicación y el intercambio de información.

Asegúrate de actualizar regularmente la lista de direcciones IP de los peers en tu red, para adaptarte a los cambios y garantizar la disponibilidad de las conexiones. Con una red P2P sólidamente estructurada, podrás aprovechar al máximo los beneficios de esta librería de comunicaciones y crear una plataforma confiable para el intercambio de datos entre los peers de tu red local.

### Manteniendo conexiones redundantes para la estabilidad de la red

Para garantizar la estabilidad y continuidad de la red P2P, es recomendable establecer conexiones redundantes entre los peers. Esto significa que cada peer debe tener múltiples conexiones con otros peers en la red, de manera que si una conexión se pierde, la red sigue funcionando sin desconectarse por completo.

La implementación de conexiones redundantes ofrece varios beneficios importantes:

1. **Resiliencia ante fallos**: Si un peer pierde la conexión con uno de sus peers, aún podrá comunicarse a través de otras conexiones disponibles. Esto evita que un único punto de fallo afecte gravemente la comunicación en la red.

2. **Mayor escalabilidad**: Al tener múltiples conexiones, la red puede expandirse y añadir nuevos peers sin comprometer la conectividad existente. Esto facilita el crecimiento de la red de forma flexible.

Hay que tener en cuenta que esta es una red P2P basada en el protocolo de difusión donde un mensaje se manda a todos los peers conectados a la máquina. Si bien es un protocolo sencillo de implementar es poco eficiente a la hora de manejar tramas inundando la red con copias del mismo. Si bien se han establecido protocolos para aligerar la carga, que se verán más adelante, este no está pensado para redes intermedias o grandes.

Recuerda mantener un monitoreo constante de las conexiones y realizar ajustes cuando sea necesario. Si una conexión redundante se vuelve inestable o se pierde, el algoritmo de enrutamiento debe ser capaz de redirigir el tráfico a través de las conexiones alternativas.

Al implementar conexiones redundantes en tu red P2P, aseguras la estabilidad y la continuidad de la comunicación, incluso en situaciones de fallos parciales. Esto fortalece la infraestructura de la red y garantiza un intercambio de datos confiable entre los peers.

## Comportamiento de un peer en la red P2P

El comportamiento de un peer en la red P2P se rige por el sistema interno de la librería de comunicaciones. A continuación, se detalla cómo opera un peer en el contexto de la red:

1. **Establecimiento de conexiones iniciales:** Dos peers pueden apuntarse mutuamente utilizando sus listas de conexiones iniciales. El cliente de un peer intentará establecer una conexión con el servidor del otro peer. Sin embargo, el sistema interno de la librería asegura que solo haya una comunicación activa entre dos peers. Si se intenta establecer una segunda conexión, esta será descartada y solo se mantendrá la conexión más rápida en afianzarse entre los dos peers.

2. **Actualización de la lista de conocidos (vecinos):** Cuando un peer se conecta al servidor de otro peer, incluso si este último no estaba inicialmente en su lista de direcciones, se incluye en su lista de conocidos, también llamados vecinos. Esto permite mantener una estructura dinámica de la red, donde los peers pueden descubrir y reconocer a otros peers activos.

3. **Conexiones regulares con vecinos:** El sistema interno de la librería intenta mantener conexiones regulares con los peers de la lista de vecinos que se encuentren desconectados. Esto implica que el peer intentará conectarse periódicamente con los peers de la lista inicial, así como con aquellos que se hayan conectado al menos una vez en el pasado. Esto asegura la estabilidad y la reconexión en caso de desconexiones temporales.

4. **Reinicio del programa y recuperación de la configuración:** Si el programa se cierra y se vuelve a abrir, en la lista de vecinos solo estarán presentes los peers de la lista inicial, olvidando las conexiones nuevas que se hayan realizado previamente. Sin embargo, si este reinicio ocurre dentro de una red que ya estaba funcionando, todos los peers activos que se hayan conectado anteriormente intentarán reconectarse. En cuestión de segundos, la red recuperará la misma configuración que existía antes del cierre, restableciendo las conexiones entre los peers.

Es importante tener en cuenta estos comportamientos al utilizar la librería de comunicaciones. El sistema interno de la librería se encarga de gestionar la conectividad y la actualización de los peers en la red P2P, facilitando la reconexión y manteniendo la estabilidad de la red incluso después de reinicios o desconexiones temporales.

## Mensajes en la red: Estructura y funcionalidad

En esta red, los mensajes se basan en los protocolos existentes y se estructuran en capas. La librería de comunicaciones utiliza un enfoque de encapsulamiento, donde la aplicación que utiliza la librería proporciona un objeto llamado "payload". La librería envuelve este objeto en su propia estructura, conocida como "cabecera", para luego distribuirlo en la red. Cada peer por el que pasa el mensaje examinará la cabecera y actuará según la información contenida en ella. Esto puede implicar extraer el contenido, redistribuir el mensaje, realizar ambas acciones o descartar el mensaje en ese punto (por ejemplo, si el peer es el remitente original del mensaje). Así, el conjunto completo se conoce como "frame", que representa la unidad que viaja por la red.

Un frame consta de diferentes secciones:

| Encabezado                                                                    | Payload                     |
| ----------------------------------------------------------------------------- | --------------------------- |
| Tipo de frame<br/>Identificador de mensaje<br/>IP de origen<br/>IP de destino | Objeto serializable de Java |

Donde:

- Tipo de frame: Indica el propósito de la transmisión y puede ser:
  
  - MessageFrame: El frame contiene un payload que debe ser entregado a otro peer.
  - PingFrame: Se utiliza cuando un peer quiere verificar la conexión con otro. No se puede insertar un payload.
  - PingAckFrame: Es la respuesta a un PingFrame. No se puede insertar un payload.
  - CloseFrame: Se utiliza cuando un peer desea informar a otro que se desconectará de la red. No se puede insertar un payload.

- Identificador de mensaje: Es un número que identifica de manera única cada mensaje.

- IP de origen: Es la dirección IP del peer que envía el mensaje.

- IP de destino: Es la dirección IP del peer al que se dirige el mensaje. Si se encuentra un asterisco (*) en este campo, el mensaje se envía a toda la red.

- Payload: Es un objeto serializable de Java que ha implementado la interfaz "Serializable".

Esta estructura de mensajes permite la comunicación eficiente entre los peers de la red. Cada peer puede enviar y recibir mensajes, y el sistema interno de la librería se encarga de manejar la distribución y procesamiento adecuados de los frames. Al utilizar esta librería de comunicaciones, puedes aprovechar esta estructura de mensajes para intercambiar información y establecer una comunicación efectiva en tu red P2P.

### Enrutamiento de un frame

El enrutamiento de mensajes en la librería de comunicaciones se realiza por difusión pero utiliza una serie de reglas para aligerar la carga y a la vez evitando los bucles de mensajes. Enviar o reenviar mensajes puede verse como la misma operación y únicamente depende se si el peer genera el mensaje o relanza a la red un mensaje que ha recibido con anterioridad.

##### Reenvío de mensajes

La librería utiliza distintas reglas para el envío y reenvío de mensajes, basándose en las direcciones IP de origen, destino y la lista de vecinos de cada peer. Es importante tener en cuenta que un mismo mensaje puede moverse por diferentes ramas de la red simultáneamente, lo que podría dar lugar a que el mensaje llegue al peer que lo emitió. Sin embargo, la librería implementa un mecanismo para evitar bucles en la red. A continuación, se describen las reglas para el reenvío de mensajes, siguiendo un orden de prioridad:

1. Si la IP de origen es la misma que la del propio peer: El mensaje se descarta y no se reenvía.
   ![Rechazo por ip de origen](./images/aceptacion_y_rechazo_por_ip_origen.png "Rechazo por ip de origen propia")
   En esta imagen puede verse como un paquete que viaja por la red y tiene *ip* de origen **x.y.z.2** al encontrarse con el peer de la misma *ip*, dicho mensaje será descartado.

2. Si el identificador del mensaje, con una ip de origen dada es menor o igual al identificador almacenado en una lista de mensajes vistos por el peer: El mensaje se descarta y no se reenvía.
   ![Rechazo por id](./images/aceptacion_y_rechazo_por_id.png "Rechazo por id conocida")
   En la imagen puede verse un mensaje que sale como *flood* desde **A** con destino a **B** y **C**. Ambos peers aceptan el mensaje y lo retransmiten **B** lo envía para **C** y **D**. **C** ya había recibido el mensaje con la misma *id* y por tanto lo descarta. Al mismo tiempo **C** también envía a **D** el mensaje que le había llegado por **A**. **D** ha recibido antes el mensasje por **B** que es el que acepta. Al llegar el de **C** poco después, al ya tener esa *id* en su registro, lo descarta.

3. Si la IP de destino está presente en la lista de vecinos del peer: El mensaje se envía únicamente a esa IP y no se realiza ningún tratamiento adicional. El mensaje es privado: si el peer no tiene la misma IP que la del destino del mensaje no va a tomarlo.
   ![Send private](./images/send_private_con_vecino.png "Send private")
   En el dibujo puede verse como desde **x.y.z.2** sale un mensaje con destino a **x.y.z.5**, como dicha estación es vecina de la anterior el mensaje sólo irá por esa rama.

4. Si la IP de destino no se encuentra en la lista de vecinos del peer: El mensaje se distribuye a todos los vecinos del peer sin realizar ningún tratamiento adicional. El mensaje es privado: si el peer no tiene la misma IP que la del destino del mensaje no va a tomarlo.
   ![Send private con destino lejano](./images/send_private_sin_vecino.png "Send private con destino lejano")
   En este caso el peer **x.y.z.2** lanza un mensaje para el peer **x.y.z.5** y como esta estación no está en su lista de vecino enviará una copia de él a todos los peers que estuvieran en dicha lista. Así el mensaje se propagará por la red hasta llegar a su destino.

5. Si la IP de destino es un asterisco (*): El mensaje se trata según su tipo y se reenvía a todos los vecinos del peer. Este mensaje circulará por toda la red y cada estación que lo reciba, al contrario de lo que ocurre en los puntos 3 y 4, tomará el mensaje y actuará en consecuencia.

#### Mensajes duplicados

El enrutamiento de mensajes simultáneos en la red puede dar lugar a que un peer reciba el mismo mensaje en momentos diferentes, lo cual podría ocasionar problemas. Además, existe el riesgo de que un mensaje quede atrapado en un bucle dentro de la red. Para evitar estos inconvenientes, la librería utiliza un diccionario que almacena pares clave/valor, donde la clave es la IP del mensaje y el valor es el identificador de mensaje más alto registrado hasta el momento. Esto permite descartar mensajes antiguos y evitar la duplicación.

El proceso de manejo de mensajes duplicados se realiza de la siguiente manera:

1. Al recibir un mensaje, el peer verifica la dirección IP de origen.

2. ¿La dirección IP de origen se encuentra en el diccionario del peer?
   
   - Si la respuesta es sí, se compara el identificador del mensaje recibido con el identificador almacenado en el diccionario para esa IP.
     
     - Si el identificador del mensaje es mayor que el almacenado en el diccionario, se procede con el mensaje según las reglas de enrutamiento establecidas.
     
     - Si el identificador del mensaje es menor o igual al almacenado en el diccionario, el mensaje se descarta y no se redistribuye.
   
   - Si la respuesta es no, se agrega la dirección IP junto con el identificador del mensaje en el diccionario del peer.

3. Fin del proceso de enrutamiento.

Siguiendo este procedimiento, se garantiza que los mensajes duplicados se manejen de manera adecuada y que solo los mensajes más recientes sean procesados y distribuidos en la red. Esto evita la duplicación innecesaria de mensajes y ayuda a mantener un flujo de comunicación eficiente y libre de bucles.

Al utilizar la librería de comunicaciones, puedes confiar en su sistema de enrutamiento de mensajes para garantizar que los mensajes sean enviados correctamente a los peers destinatarios, ya sea de forma privada o como mensajes globales para toda la red. Además, la gestión de mensajes duplicados asegura que los peers no sean inundados con mensajes repetidos y que los recursos de la red se utilicen de manera óptima.

## Uso de la librería

### Instalación

Para comenzar a utilizar la librería de comunicaciones, asegúrate de tener instalada la versión mínima requerida de Java 10 con el framework headless.

El proceso de incorporación de la librería a tu proyecto es sencillo. Simplemente coloca todo el contenido del paquete "communications" en la carpeta "src" de tu proyecto. Además, deberás ubicar en la raíz del proyecto el archivo `connections.properties` con la siguiente estructura:

```
server_port=<puerto_del_servidor>
peers=<lista_de_peers>
```

Donde:

* `<puerto_del_servidor>` es el puerto en el que tu aplicación escuchará nuevas conexiones. Por ejemplo, puedes utilizar el puerto 1234.

* `<lista_de_peers>` es una lista de direcciones IP separadas por comas a las que tu aplicación intentará conectarse. Por ejemplo:

```
server_port=1234
peers=111.111.111.111,222.222.222.222
```

Asegúrate de reemplazar las direcciones IP de ejemplo con las direcciones reales que corresponda utilizar en tu proyecto.

Una vez que hayas realizado estos pasos, la librería de comunicaciones estará lista para ser utilizada en tu proyecto.

### Inicialización

Para comenzar a utilizar la librería de comunicaciones, sigue los siguientes pasos:

1. Crea una instancia de la clase `ConnectionController` llamando a su constructor sin argumentos:

```java
var comm = new ConnectionController();
```

2. Crea un objeto que herede de la interfaz `P2PCommListener`. Este objeto será responsable de recibir los mensajes provenientes de la red y cualquier otra información relevante proporcionada por la librería. Por ejemplo, llamémoslo `messenger`:

```java
var messenger = new Messenger(); // Messenger debe implementar la interfaz P2PCommListener
```

3. Establece el objeto `comm` creado anteriormente como la comunicación (communication) del objeto `messenger` utilizando el método `setComm()`:

```java
messenger.setComm(comm);
```

4. Establece el objeto `messenger` como el listener de comunicación (communication listener) de la instancia de `ConnectionController` utilizando el método `setCommListener()`:

```java
comm.setCommListener(messenger);
```

5. Finalmente, inicializa la librería llamando al método `initialize()` de la instancia de `ConnectionController`:

```java
comm.initialize();
```

Una vez completados estos pasos, la librería estará lista para recibir y enviar mensajes a través de la red. Asegúrate de implementar la lógica necesaria en el objeto `messenger` para manejar los mensajes recibidos y llevar a cabo las acciones deseadas en tu aplicación.

## API

La librería proporciona una serie de métodos para enviar mensajes a la red, facilitando la comunicación con otros peers de forma transparente. A continuación se describen los métodos expuestos por una instancia de la clase `ConnectionController` para enviar mensajes.

### Mensajes salientes para toda la red

El método `sendFlood(Object message)` permite enviar un mensaje a toda la red. El mensaje especificado en el parámetro `message` será escuchado y tratado por cada peer de la red. Para utilizar este método, llama a `sendFlood(Object message)` en la instancia de `ConnectionController`. Esto asegurará que se entregue una copia del mensaje a cada vecino.

Ejemplo de uso:

```java
var message = new RequestShipIdMessage();
message.petitionaryId = hashCode();
message.team = team;
comm.sendFlood(message);
```

En el ejemplo anterior, se crea un objeto `RequestShipIdMessage` y se asignan algunos valores a sus propiedades. Luego, se utiliza `sendFlood()` para enviar el mensaje a toda la red.

Recuerda adaptar el ejemplo a tu propia implementación y ajustar el tipo de mensaje y los datos que deseas enviar.

### Mensaje privado

El método `sendPrivate(String ip, Object message)` permite enviar un mensaje privado a un peer específico en la red. El mensaje especificado en el parámetro `message` será recibido únicamente por el peer que tenga la dirección IP coincidente con la especificada en el parámetro `ip`. Los demás peers por los que pase el mensaje lo ignorarán y solo lo reenviarán.

El comportamiento de reenvío del mensaje depende de si el peer actual comparte la dirección IP especificada en el argumento `ip`:

- Si el peer tiene un vecino con la misma dirección IP especificada, solo retransmitirá el mensaje a ese vecino.
- Si el peer no tiene un vecino con la misma dirección IP, retransmitirá el mensaje a todos sus vecinos.

A continuación se muestra un ejemplo de uso de este método:

```java
comm.sendPrivate("192.168.0.32", String.valueOf(0));
```

En el ejemplo anterior, se utiliza `sendPrivate()` para enviar un mensaje con el valor "0" a un peer con la dirección IP "192.168.0.32". Solo ese peer recibirá y procesará el mensaje.

Asegúrate de adaptar el ejemplo a tu propia implementación y de especificar la dirección IP correcta y el tipo de mensaje que deseas enviar.

### Desconexión voluntaria

El método `sendDisconnectionAdvise()` se utiliza cuando un peer desea salir de la red de forma controlada. Al llamar a este método, se envía un aviso a todos los vecinos del peer, informándoles que la desconexión será voluntaria. Los vecinos eliminarán al peer de su lista de conocidos, lo que significa que no intentarán reconectarse con él una vez que salga de la red. Es importante destacar que este mensaje de desconexión no se redistribuirá más allá de los vecinos directos.

A continuación se muestra un ejemplo de uso del método:

```java
comm.sendDisconnectionAdvise();
```

En el ejemplo anterior, se utiliza `sendDisconnectionAdvise()` para enviar un aviso de desconexión voluntaria a todos los vecinos del peer. Esto les informará que el peer se desconectará de la red de forma controlada.

Recuerda llamar a este método antes de que el peer cierre su conexión con la red para garantizar una desconexión adecuada y que los vecinos eliminen al peer de su lista de conocidos.

Asegúrate de adaptar el ejemplo a tu propia implementación y de realizar cualquier otro paso necesario para cerrar correctamente la conexión del peer con la red.

### Mensajes entrantes y otros eventos

La librería se comunica con el programa anfitrión mediante la interfaz `P2PCommListener`. Esta interfaz define métodos que deben ser implementados por el anfitrión para recibir y manejar los mensajes entrantes y otros eventos relacionados con la red P2P. A continuación, se describen los métodos de la interfaz:

### Mensaje entrante

El método `onIncomingMessage(String ip, Object message)` se ejecuta cuando llega un mensaje a la aplicación anfitriona que debe ser interpretado. El parámetro `ip` indica la dirección de procedencia del mensaje y el parámetro `message` contiene el cuerpo del mensaje.

Es importante destacar que el parámetro `message` es de tipo `Object` debido a que la interfaz utiliza la clase base `Object` de Java para representar cualquier tipo de mensaje. Sin embargo, en la implementación real, se espera que los mensajes sean de tipos más especializados. Por lo tanto, es necesario realizar una verificación de tipos utilizando el operador `instanceof` para determinar el tipo real del mensaje y realizar las acciones correspondientes.

A continuación, se muestra un ejemplo de cómo implementar el método `onIncomingMessage` y realizar la verificación de tipos:

```java
@Override
public void onIncomingMessage(String ip, Object message) {
    if (message instanceof ShipScreenChangeMessage) {
        ShipScreenChangeMessage m = (ShipScreenChangeMessage) message;

        // Realizar acciones relacionadas con el mensaje ShipScreenChangeMessage

    } else if (message instanceof AccelerateShipMessage) {
        AccelerateShipMessage m = (AccelerateShipMessage) message;

        // Realizar acciones relacionadas con el mensaje AccelerateShipMessage

    } else if (message instanceof RotateShipMessage) {
        RotateShipMessage m = (RotateShipMessage) message;

        // Realizar acciones relacionadas con el mensaje RotateShipMessage

    } else if (message instanceof RequestShipIdMessage) {
        RequestShipIdMessage m = (RequestShipIdMessage) message;

        // Realizar acciones relacionadas con el mensaje RequestShipIdMessage

    } else if (message instanceof IdScreenMessage) {
        IdScreenMessage m = (IdScreenMessage) message;

        // Realizar acciones relacionadas con el mensaje IdScreenMessage

    }
}
```

En el ejemplo anterior, se realiza la verificación de tipos para diferentes mensajes y se realiza la acción correspondiente según el tipo de mensaje recibido. Es importante adaptar el código a los tipos de mensajes que se esperan en tu aplicación y realizar las acciones necesarias para cada tipo de mensaje.

Recuerda que este es solo un ejemplo y debes adaptarlo a tu propia implementación y a los mensajes específicos de tu aplicación.

### Conexión nueva establecida

El método `onNewConnection(String ip)` se ejecuta cuando se establece una nueva conexión con un vecino de la red P2P. El parámetro `ip` representa la dirección de red del peer con el que se ha establecido la conexión.

La librería se encarga internamente de manejar las conexiones y reconexiones en caso de caídas accidentales u otros eventos de bajo nivel. Sin embargo, a nivel de aplicación, puede resultar útil conocer los vecinos que están conectados para realizar tareas a un nivel más alto con ellos.

Dentro de este método, puedes implementar la lógica necesaria para manejar la nueva conexión. Por ejemplo, puedes mantener un registro de los vecinos conectados, establecer comunicación adicional con ellos o iniciar intercambios de datos específicos.

A continuación, se muestra un ejemplo de cómo implementar el método `onNewConnection`:

```java
@Override
public void onNewConnection(String ip) {
    // Realizar acciones relacionadas con la nueva conexión
    // por ejemplo, mantener un registro de los vecinos conectados
    // o establecer comunicación adicional con ellos
}
```

Dentro de este método, puedes agregar la lógica personalizada que necesites para manejar la nueva conexión según los requisitos de tu aplicación.

Recuerda que este es solo un ejemplo y debes adaptarlo a tu propia implementación y a las necesidades específicas de tu aplicación.

### Conexión perdida

El método `onConnectionLost(String ip)` se ejecuta cuando se pierde la conexión con un vecino de la red P2P de forma inesperada. El parámetro `ip` representa la dirección de red del vecino que se ha desconectado.

La librería internamente intentará periódicamente reconectarse con el vecino que se ha desconectado. Sin embargo, a nivel de aplicación, puede resultar útil tener conocimiento de esta caída temporal de un vecino y tomar acciones adecuadas, como suspender el envío de mensajes a ese vecino hasta que se vuelva a conectar.

Dentro de este método, puedes implementar la lógica necesaria para manejar la pérdida de conexión. Por ejemplo, puedes realizar acciones como suspender temporalmente el envío de mensajes a ese vecino, mantener un registro de los vecinos desconectados, notificar al usuario de la desconexión, o cualquier otra acción que sea relevante para tu aplicación.

A continuación, se muestra un ejemplo de cómo implementar el método `onConnectionLost`:

```java
@Override
public void onConnectionLost(String ip) {
    // Realizar acciones relacionadas con la pérdida de conexión
    // por ejemplo, suspender temporalmente el envío de mensajes a ese vecino
    // o mantener un registro de los vecinos desconectados
}
```

Dentro de este método, puedes agregar la lógica personalizada que necesites para manejar la pérdida de conexión según los requisitos de tu aplicación.

Recuerda que este es solo un ejemplo y debes adaptarlo a tu propia implementación y a las necesidades específicas de tu aplicación.

### Conexión cerrada

El método `onConnectionClosed(String ip)` se ejecuta cuando un vecino se ha desconectado de forma voluntaria de la red P2P. El parámetro `ip` representa la dirección de red del vecino que se ha desconectado.

Cuando un vecino se desconecta voluntariamente, la librería lo eliminará de su lista de vecinos y no intentará reconectarse con él. Esto suele suceder cuando un peer desea salir de la red de forma definitiva.

A nivel de aplicación, es interesante tener conocimiento de este cierre definitivo de un vecino, ya que puedes liberar los recursos que estaban vinculados a ese vecino, lo cual puede incluir liberación de memoria y tiempo de proceso en el programa.

Dentro del método `onConnectionClosed`, puedes implementar la lógica necesaria para manejar el cierre de conexión. Por ejemplo, puedes liberar los recursos asociados al vecino que se ha desconectado, realizar alguna limpieza adicional o notificar al usuario sobre la desconexión definitiva.

A continuación, se muestra un ejemplo de cómo implementar el método `onConnectionClosed`:

```java
@Override
public void onConnectionClosed(String ip) {
    // Liberar recursos asociados al vecino que se ha desconectado
    // Realizar limpieza adicional si es necesario
    // Notificar al usuario sobre la desconexión definitiva
}
```

Recuerda que este es solo un ejemplo y debes adaptarlo a tu propia implementación y a las necesidades específicas de tu aplicación.

## Errores comunes

Aquí se mencionan algunos errores comunes que puedes encontrar al utilizar la librería y cómo solucionarlos:

1. **Puerto de servidor sin definir**: En el archivo `connections.properties`, asegúrate de haber definido la propiedad `server_port` con un número válido entre 1024 y 65535. Si no se ha definido correctamente, la librería no podrá iniciar el servidor y establecer conexiones con otros clientes. Para solucionar este problema, edita el archivo `connections.properties` y define correctamente el número de puerto.

2. **Puerto de servidor en uso**: Si al iniciar el socket de servidor, la librería encuentra que el puerto está ocupado por otra aplicación, lanzará un error y cerrará la aplicación. Esto puede ocurrir si otro programa ya está utilizando ese puerto. Para solucionar este problema, asegúrate de cerrar la aplicación que está ocupando el puerto o elige otro número de puerto en el archivo `connections.properties`.

3. **La conexión cae frecuentemente**: Si experimentas desconexiones frecuentes, puede haber varias causas. Es útil revisar los registros que deja la aplicación en la salida estándar (consola) para obtener más información sobre los errores. Algunas posibles causas son:
   
   - Conexión de mala calidad: Verifica las propiedades de conexión y utiliza herramientas del sistema operativo para comprobar la calidad de la conexión.
   - Problemas de serialización: Si estás enviando objetos como mensajes, asegúrate de que los objetos se serialicen correctamente antes de enviarlos.
   - Problemas de deserialización: Verifica que estés deserializando correctamente los mensajes que provienen de la red y que coincidan con los objetos esperados.

Si encuentras alguno de estos errores, sigue las indicaciones proporcionadas para solucionarlos y asegúrate de revisar los registros y mensajes de error para obtener más información sobre la causa específica del problema.

## Resumen

En resumen, la librería proporciona una herramienta poderosa para establecer redes P2P y facilitar la comunicación entre peers. Con su API intuitiva, puedes enviar mensajes a toda la red, mensajes privados a peers específicos y gestionar eventos como la conexión y desconexión de peers. Sin embargo, es importante tener en cuenta algunos errores comunes, como puertos incorrectamente definidos o en uso, y problemas de conexión o serialización. Al comprender y solucionar estos problemas, podrás aprovechar al máximo la funcionalidad de la librería y construir aplicaciones robustas y eficientes basadas en redes P2P. Explora la documentación y experimenta con la librería para descubrir todas las posibilidades que ofrece en tus proyectos. ¡Buena suerte con tu desarrollo P2P!
